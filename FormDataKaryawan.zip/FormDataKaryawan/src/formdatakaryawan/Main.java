package formdatakaryawan;

public class Main {

    public static void main(String[] args) {
        FormKaryawan formKaryawan = new FormKaryawan();
        formKaryawan.setVisible(true);
    }
    
}
